import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'Tela1.dart';
import 'Tela2.dart';
import 'Tela3.dart';
import 'Tela4.dart';
import 'Tela5.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget { // Classe MyApp que herda de StatelessWidget
  const MyApp({super.key}); // Construtor constante para MyApp

  @override
  Widget build(BuildContext context) { // Método build que retorna o widget principal do app
    return MaterialApp( // MaterialApp: Widget que define as configurações gerais do app
      debugShowCheckedModeBanner: false,
      title:'Rotas Nomeadas',
      initialRoute: '/' ,
      routes: {'/':(context) => Tela1(),
        '/tela de login':(context) => Tela2(),
        '/terceira':(context) => Tela3(),
        '/quarta':(context) => Tela4(),
        '/quinta':(context) => Tela5(),

      },
    );

  }
}
